Snacks Plus for Kerbal Space Program

Original design by: Troy Gruetzmacher
Continuation by: Michael Billard (Angel-125)

1.1
- Updated for KSP 1.1
- Removed the need for the ModuleManager patch to equip crewed pods with Snacks. 