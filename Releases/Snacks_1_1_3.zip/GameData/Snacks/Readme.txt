Snacks!

Original mod by: Troy Gruetzmacher
Continuation by: Michael Billard (Angel-125)

INSTALLATION
Delete any previous instances in GameData/Snacks
Copy the files in the zip folder over to GameData/Snacks

REVISION HISTORY

1.1.3
- Updated to KSP 1.1.1
- Fixed name in versioning file

1.1.2
- Fixed NREs
- Cleaned up the Module Manager patch. Thanks for the hints, Badsector! :)

1.1.1
- Re-added missing Snack Grinder
- Module Manager patch fixed to add Snacks to parts with up to 16 crewmembers
- Snacks won't be added to parts that already have Snacks
- Added MiniAVC support

1.1
- Updated for KSP 1.1
- Removed the need for the ModuleManager patch to equip crewed pods with Snacks.
